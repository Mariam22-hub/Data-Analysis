Sites that were helpful:
w3resources
stack overflow
geeksforgeeks
tutorialspoint
