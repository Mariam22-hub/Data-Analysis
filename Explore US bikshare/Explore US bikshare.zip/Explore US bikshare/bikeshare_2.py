import time
import pandas as pd
import numpy as np
import datetime as dt

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

months = ["january", "february", "march", "april", "may", "june"]
days = ["saturday", "monday", "sunday", "tuesday", "wednesday", "thursday", "friday"]
filters = ["both", "neither", "day", "month"]
choices = ["yes", "no"]


def validate(data, selection):
    sel = selection

    while (sel not in data):
        sel = input("Please enter a valid input:\n")
    
    return sel


def get_filters():
    # """
    # Asks user to specify a city, month, and day to analyze.

    # Returns:
    #     (str) city - name of the city to analyze
    #     (str) month - name of the month to filter by, or "all" to apply no month filter
    #     (str) day - name of the day of week to filter by, or "all" to apply no day filter
    # """
    print('Hello! Let\'s explore some US bikeshare data!')
    
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    cityName = input("Please choose from (chicago, New York City, Washington):\n")
    
    #exception handling
    cityName = validate(CITY_DATA, cityName.lower())

    #determining the kind of filter used
    filterChoice = input("Would you like to filter data by Month, Day, both, or neither:\n")
    
    #exception handling
    filterChoice = validate(filters, filterChoice.lower())
    
    #default values
    month = None
    day = None

    if (filterChoice == "neither"):
        print("No filter will be used\n")
    
    if (filterChoice == "both" or filterChoice == "day"):
        day = input("please enter name of the day (saturday, sunday...etc)\n")

        #exception handling
        day = validate(days, day.lower())

    if (filterChoice == "both" or filterChoice == "month"):
        month = input("please enter name of the month (january, february, march...june):\n")

        #exception handling
        month = validate(months, month.lower())
    


    print('-'*40)
    return cityName, month, day


def load_data(city, month, day):
    # """
    # Loads data for the specified city and filters by month and day if applicable.

    # Args:
    #     (str) city - name of the city to analyze
    #     (str) month - name of the month to filter by, or "all" to apply no month filter
    #     (str) day - name of the day of week to filter by, or "all" to apply no day filter
    # Returns:
    #     df - Pandas DataFrame containing city data filtered by month and day
    # """
    #loading required data
    df = pd.read_csv(CITY_DATA[city])
    
    # data may have NaN values in (birth year) column
    # it is best if we drop the rows containing this data as we cant estimate it in any way by the given info
    #For the gender column, NaN will be replaced with "Not specified"
    #only applicable for new york and chicago datasets
    if (city == "chicago" or city == "new york city"):
        df["Gender"] = df["Gender"].fillna("Not Specified")
        df.dropna(subset=["Birth Year"], axis=0, inplace=True)

    #  Before any filtering occurs, it's important to parse the dates into datetime objects
    #  as it'll be easier to extract days and months individually
    df["Start Time"] = pd.to_datetime(df["Start Time"])
    df["End Time"] = pd.to_datetime(df["End Time"])

    if (month != None):
        #filtering by month
        df = df[df["Start Time"].dt.month_name() == month.capitalize()]

    if(day != None):
        #filtering data by day 
        df = df[df["Start Time"].dt.day_name() == day.capitalize()]
    
    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    commonMonth = df["Start Time"].dt.month.mode()
    commonMonth = commonMonth.get(key = 0)

    print("The most common month is: " + months[commonMonth-1].capitalize())

    # display the most common day of week
    commonDay = df["Start Time"].dt.day_name().mode()
    commonDay = commonDay.get(key = 0)

    print("The most common day is: " + commonDay)
    
    # display the most common start hour
    commonHour = df["Start Time"].dt.hour.mode()
    commonHour = commonHour.get(key = 0)
    print("The most common Hour is: Hour " + str(commonHour))

    print("\nThis took %s seconds." % (time.time() - start_time)+ "\n")
    print('-'*40)


def commonStations(df, station):
    common_station = df[station].mode()
    return common_station.get(key = 0)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display the most commonly used start station
    commonStartstation = commonStations(df, "Start Station")
    print ("The most common Start station is: " + commonStartstation)
    
    # display most commonly used end station
    commonEndStation = commonStations(df, "End Station")
    print ("The most common End station is: " + commonEndStation)

    # display the most frequent combination of start station and end station trip
    combinationStation = (df["Start Station"] + " -> " + df["End Station"]).mode()
    combinationStation = combinationStation.get(key=0)
    print ("The most common combination of start and end stations is: " + "( " + combinationStation + " )")
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


#function to process time
def calculateTime(seconds):
    
    trip_seconds = seconds
    hours = trip_seconds // 3600
    trip_seconds %= 3600
    minutes = trip_seconds // 60
    trip_seconds %= 60

    print ("Total time travelled: {} Hours, {} Minutes, {} Seconds.".format(hours, minutes, trip_seconds))
    print("Another format to display the total time travelled: " + str(dt.timedelta(seconds = int(seconds))) + "\n")


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # calculate and display total travel time
    print("Calculating total time for time travel...")
    sec = df['Trip Duration'].sum()
    calculateTime(sec)

    
    # calculate and display mean travel time
    print("Calculating total average for time travel...")
    sec = df['Trip Duration'].mean()
    calculateTime(sec)
    

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df, city):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    print("User Types' Count......")
    
    users = df["User Type"].value_counts()
    print(users)
    print("\n")

    # Display counts of gender
    if (city == "chicago" or city == "new york city"):
        
        print("Genders' counts......")

        usersGenders = df["Gender"].value_counts()
        print(usersGenders)
        print("\n")
        
        # Display earliest birth date
        oldest = df["Birth Year"].min()
        print("Oldest year of birth is: " + str(oldest))

        #Display youngest user
        youngest = df["Birth Year"].max()
        print("Most recent year of birth is: "+ str(youngest))

    else:
        print("\nNo data available")
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def printData(df):
    print("Printing the next 5 rows in the dataframe...")

    x = 0
    y = 5
    
    while (len(df.index) >= y):

        for i in range(x,y):

            print("{")
            ser = pd.Series(data = df.iloc[i])
            ser.rename(index={"Unnamed: 0" : "ID"}, inplace=True)
            print(ser)
    
            print("}\n")
        
        choice = input("Do you wish to print more data? Yes/No\n")
        choice = validate(choices, choice.lower())

        if (choice != "no"):
            x+=5
            y+=5
        else:
            break

def main():
    
    while True:

        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df, city)

        print_data = input("Do you wish to display data? Yes/No\n")
        print_data = validate(choices, print_data.lower())
        
        if (print_data.lower() != "no"):
            printData(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        restart = validate(choices, restart.lower())

        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()
